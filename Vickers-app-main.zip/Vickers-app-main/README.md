# Vickers App
This is the offline-first messaging app.
